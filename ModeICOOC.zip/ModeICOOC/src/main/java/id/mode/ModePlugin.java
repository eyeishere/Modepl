package id.mode;

import net.kyori.adventure.inventory.Book;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class ModePlugin extends JavaPlugin implements Listener, TabExecutor {

    public enum Mode {
        OOC("OOC", NamedTextColor.GRAY),
        IC("IC", NamedTextColor.GREEN),
        IC_RECORD("IC+record", NamedTextColor.RED),
        IC_LIVE("IC+live", TextColor.color(0xAA55FF));

        final String label;
        final TextColor color;

        Mode(String label, TextColor color) {
            this.label = label;
            this.color = color;
        }
    }

    private final Map<UUID, Mode> modes = new HashMap<>();
    private File dataFile;

    @Override
    public void onEnable() {
        dataFile = new File(getDataFolder(), "data.yml");
        loadData();
        getServer().getPluginManager().registerEvents(this, this);
        var cmd = getCommand("mode");
        if (cmd != null) {
            cmd.setExecutor(this);
            cmd.setTabCompleter(this);
        }
        for (Player p : Bukkit.getOnlinePlayers()) updateTab(p);
    }

    @Override
    public void onDisable() {
        saveData();
        for (Player p : Bukkit.getOnlinePlayers()) p.playerListName(null);
    }

    // ---------- Data ----------

    public Mode getMode(Player p) {
        return modes.getOrDefault(p.getUniqueId(), Mode.OOC);
    }

    public void setMode(Player p, Mode mode) {
        modes.put(p.getUniqueId(), mode);
        updateTab(p);
        saveData();
        p.sendMessage(Component.text("Mode kamu sekarang: ", NamedTextColor.GRAY)
                .append(Component.text(mode.label, mode.color, TextDecoration.BOLD)));
    }

    private void loadData() {
        if (!dataFile.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dataFile);
        for (String key : y.getKeys(false)) {
            try {
                modes.put(UUID.fromString(key), Mode.valueOf(y.getString(key, "OOC")));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void saveData() {
        YamlConfiguration y = new YamlConfiguration();
        modes.forEach((id, m) -> y.set(id.toString(), m.name()));
        try {
            getDataFolder().mkdirs();
            y.save(dataFile);
        } catch (IOException e) {
            getLogger().warning("Gagal menyimpan data.yml: " + e.getMessage());
        }
    }

    // ---------- Tab list ----------

    private void updateTab(Player p) {
        Mode m = getMode(p);
        p.playerListName(Component.text(p.getName(), NamedTextColor.WHITE)
                .append(Component.text(" [", NamedTextColor.DARK_GRAY))
                .append(Component.text(m.label, m.color))
                .append(Component.text("]", NamedTextColor.DARK_GRAY)));
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        updateTab(e.getPlayer());
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        saveData();
    }

    // ---------- Book UI ----------

    private Component button(String text, TextColor color, String command, String hover) {
        return Component.text("[ " + text + " ]", color, TextDecoration.BOLD)
                .clickEvent(ClickEvent.runCommand(command))
                .hoverEvent(HoverEvent.showText(Component.text(hover, NamedTextColor.GRAY)));
    }

    public void openBook(Player p) {
        Mode cur = getMode(p);
        Component page = Component.text("MODE IC / OOC\n", NamedTextColor.DARK_BLUE, TextDecoration.BOLD)
                .append(Component.text("\nMode saat ini:\n", NamedTextColor.BLACK))
                .append(Component.text(cur.label + "\n\n", cur.color, TextDecoration.BOLD))
                .append(button("OOC (off)", NamedTextColor.DARK_GRAY, "/mode off", "Keluar karakter"))
                .append(Component.newline()).append(Component.newline())
                .append(button("IC (on)", NamedTextColor.DARK_GREEN, "/mode on", "Masuk karakter"))
                .append(Component.newline()).append(Component.newline())
                .append(button("IC + Record", NamedTextColor.DARK_RED, "/mode on record", "IC sambil merekam"))
                .append(Component.newline()).append(Component.newline())
                .append(button("IC + Live", NamedTextColor.DARK_PURPLE, "/mode on live", "IC sambil live"));

        p.openBook(Book.book(Component.text("Mode"), Component.text("Server"), page));
    }

    // ---------- Command ----------

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini hanya untuk pemain.");
            return true;
        }

        if (args.length == 0) {
            openBook(p);
            return true;
        }

        String a0 = args[0].toLowerCase(Locale.ROOT);
        switch (a0) {
            case "off" -> {
                setMode(p, Mode.OOC);
            }
            case "on" -> {
                if (args.length >= 2) {
                    switch (args[1].toLowerCase(Locale.ROOT)) {
                        case "record" -> setMode(p, Mode.IC_RECORD);
                        case "live" -> setMode(p, Mode.IC_LIVE);
                        default -> p.sendMessage(Component.text("Pakai: /mode on [record|live]", NamedTextColor.RED));
                    }
                } else {
                    setMode(p, Mode.IC);
                }
            }
            default -> p.sendMessage(Component.text("Pakai: /mode <on|off> [record|live]", NamedTextColor.RED));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("on", "off")) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("on")) {
            for (String s : List.of("record", "live")) if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
